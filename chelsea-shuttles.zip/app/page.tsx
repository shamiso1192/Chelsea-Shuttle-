import Hero from "@/components/hero"
import About from "@/components/about"
import Services from "@/components/services"
import Routes from "@/components/routes"
import Pricing from "@/components/pricing"
import Gallery from "@/components/gallery"
import Contact from "@/components/contact"
import WhatsAppButton from "@/components/whatsapp-button"

export default function Home() {
  return (
    <main className="min-h-screen">
      <Hero />
      <About />
      <Services />
      <Routes />
      <Pricing />
      <Gallery />
      <Contact />
      <WhatsAppButton />
    </main>
  )
}
