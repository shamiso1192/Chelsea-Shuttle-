"use client"

import { Button } from "@/components/ui/button"
import Image from "next/image"

export default function Hero() {
  return (
    <section id="home" className="relative h-[80vh] flex items-center justify-center text-white">
      {/* Background Image */}
      <div className="absolute inset-0 z-0">
        <Image
          src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/taxi%26trailer-WErDepWFqWjT5kuzc8wvLS3CqntirS.jpg"
          alt="Chelsea Shuttles Vehicle"
          fill
          className="object-cover brightness-50"
          priority
        />
      </div>

      {/* Content */}
      <div className="relative z-10 text-center px-4 max-w-4xl">
        <h1 className="text-4xl md:text-6xl font-bold mb-4 text-balance">Welcome to Chelsea Shuttles</h1>
        <p className="text-xl md:text-2xl mb-8 text-pretty">
          Reliable. Affordable. Safe travel between Cape Town & Zimbabwe.
        </p>
        <Button
          size="lg"
          className="bg-accent hover:bg-accent/90 text-white text-lg px-8 py-6"
          onClick={() => document.getElementById("routes")?.scrollIntoView({ behavior: "smooth" })}
        >
          Book Now
        </Button>
      </div>
    </section>
  )
}
