export default function Pricing() {
  return (
    <section id="pricing" className="py-20 px-4 bg-muted/30">
      <div className="container mx-auto max-w-4xl">
        <h2 className="text-4xl font-bold text-center mb-12 text-primary">Goods Transport Pricing</h2>

        <div className="overflow-x-auto mb-8">
          <table className="w-full border-collapse bg-white shadow-lg rounded-lg overflow-hidden">
            <thead>
              <tr className="bg-primary text-white">
                <th className="p-4 text-left">Weight (kg)</th>
                <th className="p-4 text-left">Price per kg (ZAR)</th>
              </tr>
            </thead>
            <tbody>
              <tr className="border-b hover:bg-muted/50">
                <td className="p-4">25 - 50 kg</td>
                <td className="p-4 font-semibold">R15</td>
              </tr>
              <tr className="border-b hover:bg-muted/50">
                <td className="p-4">51 - 100 kg</td>
                <td className="p-4 font-semibold">R12</td>
              </tr>
              <tr className="border-b hover:bg-muted/50">
                <td className="p-4">101 - 200 kg</td>
                <td className="p-4 font-semibold">R10</td>
              </tr>
              <tr className="hover:bg-muted/50">
                <td className="p-4">201 kg +</td>
                <td className="p-4 font-semibold">R8</td>
              </tr>
            </tbody>
          </table>
        </div>

        <div className="text-center bg-accent/10 p-6 rounded-lg border-l-4 border-accent">
          <h3 className="text-2xl font-bold text-primary">🎟️ Bus Ticket: R1800 one way (Cape Town ↔ Harare)</h3>
        </div>
      </div>
    </section>
  )
}
