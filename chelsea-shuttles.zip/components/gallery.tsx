"use client"

import { useState } from "react"
import Image from "next/image"

const images = [
  {
    src: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/front%20of%20the%20bus-shbJjqUEidgBwDrD6SLWissq1vUNjR.avif",
    alt: "Front View of Bus",
  },
  {
    src: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/vans-peHSd9JHVS0WkXQzfjXb3hZzyzgNqR.jpg",
    alt: "Fleet Vans",
  },
  {
    src: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/good%20ready%20to%20be%20transported.-14Gpc3f0pg3eCfrFgm8Mrg6ZDlATXt.avif",
    alt: "Goods Transport",
  },
  {
    src: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/taxi%26trailer-WErDepWFqWjT5kuzc8wvLS3CqntirS.jpg",
    alt: "Taxi and Trailer",
  },
]

export default function Gallery() {
  const [selectedImage, setSelectedImage] = useState<string | null>(null)

  return (
    <section className="py-20 px-4 bg-background">
      <div className="container mx-auto max-w-6xl">
        <h2 className="text-4xl font-bold text-center mb-12 text-primary">Gallery</h2>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {images.map((image, index) => (
            <div
              key={index}
              className="relative h-48 rounded-lg overflow-hidden cursor-pointer hover:scale-105 transition-transform shadow-lg"
              onClick={() => setSelectedImage(image.src)}
            >
              <Image src={image.src || "/placeholder.svg"} alt={image.alt} fill className="object-cover" />
            </div>
          ))}
        </div>
      </div>

      {/* Lightbox */}
      {selectedImage && (
        <div
          className="fixed inset-0 bg-black/90 z-50 flex items-center justify-center p-4"
          onClick={() => setSelectedImage(null)}
        >
          <div className="relative w-full max-w-4xl h-[80vh]">
            <Image src={selectedImage || "/placeholder.svg"} alt="Gallery Image" fill className="object-contain" />
          </div>
        </div>
      )}
    </section>
  )
}
