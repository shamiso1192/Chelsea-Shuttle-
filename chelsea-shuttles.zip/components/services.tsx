import Image from "next/image"
import { Card, CardContent } from "@/components/ui/card"

const services = [
  {
    title: "Intercity Travel",
    description: "Comfortable long-distance travel across South Africa and Zimbabwe with free WiFi onboard.",
    image: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/vans-peHSd9JHVS0WkXQzfjXb3hZzyzgNqR.jpg",
  },
  {
    title: "Parcel Delivery",
    description: "Secure, fast, and affordable cross-border parcel delivery. We collect goods from your doorstep.",
    image:
      "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/good%20ready%20to%20be%20transported.-14Gpc3f0pg3eCfrFgm8Mrg6ZDlATXt.avif",
  },
  {
    title: "Tour Services",
    description: "Explore Southern Africa with our professional drivers and clean, comfortable shuttles.",
    image:
      "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/front%20of%20the%20bus-shbJjqUEidgBwDrD6SLWissq1vUNjR.avif",
  },
]

export default function Services() {
  return (
    <section id="services" className="py-20 px-4 bg-muted/30">
      <div className="container mx-auto max-w-6xl">
        <h2 className="text-4xl font-bold text-center mb-12 text-primary">Our Services</h2>

        <div className="grid md:grid-cols-3 gap-8">
          {services.map((service, index) => (
            <Card key={index} className="overflow-hidden hover:shadow-xl transition-shadow">
              <div className="relative h-48">
                <Image src={service.image || "/placeholder.svg"} alt={service.title} fill className="object-cover" />
              </div>
              <CardContent className="p-6">
                <h3 className="text-xl font-bold mb-3 text-primary">{service.title}</h3>
                <p className="text-muted-foreground leading-relaxed">{service.description}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  )
}
