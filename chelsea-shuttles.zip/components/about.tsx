import Image from "next/image"

export default function About() {
  return (
    <section id="about" className="py-20 px-4 bg-background">
      <div className="container mx-auto max-w-6xl">
        <h2 className="text-4xl font-bold text-center mb-12 text-primary">Who We Are</h2>

        <div className="grid md:grid-cols-2 gap-8 items-center">
          <div className="relative h-[400px] rounded-lg overflow-hidden shadow-xl">
            <Image
              src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/taxi%26trailer-WErDepWFqWjT5kuzc8wvLS3CqntirS.jpg"
              alt="Chelsea Shuttle Bus with Trailer"
              fill
              className="object-cover"
            />
          </div>

          <div className="space-y-4">
            <p className="text-lg leading-relaxed">
              Chelsea Shuttles is a trusted passenger and goods transport service connecting Cape Town with major
              destinations across Zimbabwe. We are committed to offering safe, reliable, and comfortable travel, making
              long-distance journeys stress-free for our passengers.
            </p>
            <p className="text-lg leading-relaxed">
              With years of experience on the road, our friendly drivers and dedicated team ensure every trip is on time
              and every client is treated with care. We provide free WiFi onboard and generous luggage allowances to
              make your journey as comfortable as possible.
            </p>
            <div className="bg-accent/10 p-6 rounded-lg border-l-4 border-accent">
              <p className="font-semibold text-lg">
                🛄 Each passenger gets 10kg hand luggage + 23kg checked luggage free!
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
