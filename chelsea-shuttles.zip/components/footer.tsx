export default function Footer() {
  return (
    <footer className="bg-primary text-white py-8">
      <div className="container mx-auto px-4 text-center">
        <p className="text-lg">&copy; {new Date().getFullYear()} Chelsea Shuttles | Cape Town, South Africa</p>
        <p className="mt-2 text-sm opacity-80">Safe and Reliable Travel You Can Trust</p>
      </div>
    </footer>
  )
}
