"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Card, CardContent } from "@/components/ui/card"
import { Mail, Phone, MapPin, Facebook } from "lucide-react"

export default function Contact() {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    message: "",
  })
  const [status, setStatus] = useState<{ type: "success" | "error" | ""; message: string }>({
    type: "",
    message: "",
  })

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    // Basic validation
    if (!formData.name || !formData.email || !formData.message) {
      setStatus({ type: "error", message: "⚠️ Please fill in all required fields." })
      return
    }

    const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
    if (!emailPattern.test(formData.email)) {
      setStatus({ type: "error", message: "⚠️ Please enter a valid email address." })
      return
    }

    setStatus({ type: "", message: "Sending message..." })

    // Simulate sending (in production, this would call an API)
    setTimeout(() => {
      setStatus({
        type: "success",
        message: "✅ Thank you for your message! We'll get back to you soon.",
      })
      setFormData({ name: "", email: "", message: "" })
    }, 1500)
  }

  return (
    <section id="contact" className="py-20 px-4 bg-muted/30">
      <div className="container mx-auto max-w-6xl">
        <h2 className="text-4xl font-bold text-center mb-12 text-primary">Contact Us / Booking Request</h2>

        <div className="grid md:grid-cols-2 gap-8">
          {/* Contact Details */}
          <Card>
            <CardContent className="p-8 space-y-6">
              <h3 className="text-2xl font-bold mb-6 text-primary">Get In Touch</h3>

              <div className="flex items-start gap-4">
                <MapPin className="text-accent mt-1" size={24} />
                <div>
                  <p className="font-semibold">Location</p>
                  <p className="text-muted-foreground">Cape Town, Western Cape, South Africa</p>
                </div>
              </div>

              <div className="flex items-start gap-4">
                <Phone className="text-accent mt-1" size={24} />
                <div>
                  <p className="font-semibold">Phone</p>
                  <p className="text-muted-foreground">+27 73 719 7959</p>
                  <p className="text-muted-foreground">+27 63 534 7874</p>
                  <p className="text-muted-foreground">+27 66 032 2231</p>
                </div>
              </div>

              <div className="flex items-start gap-4">
                <Mail className="text-accent mt-1" size={24} />
                <div>
                  <p className="font-semibold">Email</p>
                  <p className="text-muted-foreground">chelseashuttles@gmail.com</p>
                </div>
              </div>

              <div className="flex items-start gap-4">
                <Facebook className="text-accent mt-1" size={24} />
                <div>
                  <p className="font-semibold">Follow Us</p>
                  <a
                    href="https://www.facebook.com/chelsea.shuttles/"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-accent hover:underline"
                  >
                    Facebook - Chelsea Shuttles
                  </a>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Contact Form */}
          <Card>
            <CardContent className="p-8">
              <form onSubmit={handleSubmit} className="space-y-4">
                <div>
                  <Input
                    type="text"
                    placeholder="Your Name"
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    required
                  />
                </div>

                <div>
                  <Input
                    type="email"
                    placeholder="Your Email"
                    value={formData.email}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                    required
                  />
                </div>

                <div>
                  <Textarea
                    placeholder="Your Message"
                    rows={5}
                    value={formData.message}
                    onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                    required
                  />
                </div>

                <Button type="submit" className="w-full bg-accent hover:bg-accent/90 text-white">
                  Send Message
                </Button>

                {status.message && (
                  <p className={`text-center ${status.type === "success" ? "text-green-600" : "text-red-600"}`}>
                    {status.message}
                  </p>
                )}
              </form>
            </CardContent>
          </Card>
        </div>
      </div>
    </section>
  )
}
