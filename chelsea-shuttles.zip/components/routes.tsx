"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import BookingModal from "./booking-modal"

const routes = [
  {
    from: "Cape Town",
    to: "Harare",
    schedule: "Every Sunday, departs 3:00 PM",
    price: "R1800",
  },
  {
    from: "Harare",
    to: "Cape Town",
    schedule: "Every Thursday, departs 8:00 AM",
    price: "R1800",
  },
]

export default function Routes() {
  const [isModalOpen, setIsModalOpen] = useState(false)
  const [selectedRoute, setSelectedRoute] = useState("")

  const handleBooking = (route: string) => {
    setSelectedRoute(route)
    setIsModalOpen(true)
  }

  return (
    <section id="routes" className="py-20 px-4 bg-background">
      <div className="container mx-auto max-w-6xl">
        <h2 className="text-4xl font-bold text-center mb-12 text-primary">Popular Routes</h2>

        <div className="grid md:grid-cols-2 gap-8 mb-8">
          {routes.map((route, index) => (
            <Card key={index} className="hover:shadow-xl transition-shadow">
              <CardContent className="p-8 text-center">
                <h3 className="text-2xl font-bold mb-4 text-primary">
                  {route.from} → {route.to}
                </h3>
                <p className="text-lg mb-2">{route.schedule}</p>
                <p className="text-3xl font-bold text-accent mb-6">{route.price}</p>
                <Button
                  className="bg-accent hover:bg-accent/90 text-white w-full"
                  onClick={() => handleBooking(`${route.from} → ${route.to}`)}
                >
                  Book Now
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="bg-accent/10 p-6 rounded-lg border-l-4 border-accent text-center">
          <p className="text-lg font-semibold">🛄 Each passenger gets 10kg hand luggage + 23kg checked luggage free!</p>
          <p className="text-lg font-semibold mt-2">📶 Free WiFi onboard all our shuttles!</p>
        </div>
      </div>

      <BookingModal isOpen={isModalOpen} onClose={() => setIsModalOpen(false)} selectedRoute={selectedRoute} />
    </section>
  )
}
